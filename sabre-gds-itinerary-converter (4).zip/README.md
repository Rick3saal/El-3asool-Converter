# El 3asool Converter

Personal flight-itinerary converter for accurate, copy-ready Sabre GDS itinerary and sell entries.

## Local Development

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

The deployable site is generated in `dist/`.

## Recommended: Publish With Vercel

1. Push this project to a GitHub repository.
2. Sign in to [Vercel](https://vercel.com) and choose **Add New > Project**.
3. Import the repository.
4. Set **Root Directory** to the folder that directly contains `package.json`.
5. Select **Vite** as the framework and **Node.js 22.x** as the Node version.
6. Vercel will detect the included `vercel.json` settings.
7. Click **Deploy**.

Every push to `main` will publish a new version automatically. A custom domain can be added under **Project Settings > Domains**.

### Vercel Build Settings

- Framework preset: `Vite`
- Root Directory: the folder containing `package.json` (normally `./`)
- Install command: `npm ci --include=dev`
- Build command: `./node_modules/.bin/vite build`
- Output directory: `dist`
- Node.js version: `22.x`

If Vercel shows only `Command "npm run build" exited with 1`, expand the build log and read the first red error above that line. The last line is only a generic summary.

Common causes:

- `vite: command not found`: Vercel omitted development dependencies. Use the install command above.
- `crypto.hash is not a function` or an engine warning: change the Vercel Node.js version to `22.x`.
- `Could not resolve entry module "index.html"` or `Missing script: build`: the Root Directory is wrong, or only part of the project was uploaded.
- `Module not found`: upload the complete project, including `src/`, `public/`, `package.json`, `package-lock.json`, `vite.config.ts`, `tsconfig.json`, and `index.html`.

### Vercel CLI Fallback (Build Locally)

If the project builds on your computer but Vercel's remote builder still fails, deploy a verified local build:

```bash
npm install
npx vercel@latest login
npx vercel@latest link
npx vercel@latest build --prod
npx vercel@latest deploy --prebuilt --prod
```

Run these commands from the folder that directly contains `package.json`. This creates Vercel's prebuilt output locally and uploads it without running the remote build again.

## Publish With Netlify

### Git-based deployment

1. Push this project to GitHub.
2. In Netlify, choose **Add new site > Import an existing project**.
3. Select the repository and deploy. The included `netlify.toml` supplies the build settings.

### Manual deployment

1. Run `npm run build`.
2. Drag the complete `dist/` folder into [Netlify Drop](https://app.netlify.com/drop).

## Publish With GitHub Pages

1. Push the project to a GitHub repository whose default branch is `main`.
2. Open **Repository Settings > Pages**.
3. Under **Build and deployment**, choose **GitHub Actions**.
4. Push to `main`, or run the **Deploy to GitHub Pages** workflow manually.

The included `.github/workflows/deploy-pages.yml` builds and publishes the application.

## Browser Requirements

- The published site must use HTTPS for reliable Clipboard API access. Vercel, Netlify, and GitHub Pages provide HTTPS automatically.
- OCR runs in the browser. Its language/worker assets may require internet access when loaded for the first time.
- AI Assist calls the selected provider directly from the browser. API keys are stored only in that browser's local storage.
- Self-learning rules and learned itineraries are also stored in local storage and are specific to the published domain and browser.

## Important When Moving Domains

Browser local storage does not transfer between domains. Learning saved on localhost, a preview URL, or an older domain will not automatically appear on the final domain. Start learning on the permanent production domain once it is connected.